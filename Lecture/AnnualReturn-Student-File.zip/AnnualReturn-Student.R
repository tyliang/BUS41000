# Please run this line before going forward [tell R the location of SP500.csv file]
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## Q1: Calculate Mean and Variance of SP500

df = read.csv(file = "SP500.csv", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
SP500 = as.numeric(sub("%", "", df$S.P.500..includes.dividends.))
mean(SP500)
sd(SP500)


## Q2: Only invest $1 in the first year
returns = matrix(rnorm(n = 5000*20, mean = [?], sd = [?]), nrow = 5000, ncol=20)/100
wealth = apply(1+returns, 1, prod)

print(mean(wealth))
print(sd(wealth))


## Q3: Invest $1 every year
returns = matrix(rnorm(n = 5000*20, mean = [?], sd = [?]), nrow = 5000, ncol=20)/100

wealth = apply(1+returns, 1, prod)
for (i in 1:19){
  wealth = wealth + apply(1+returns[,(i+1):20], 1, prod)
}

print(mean(wealth))
print(sd(wealth))