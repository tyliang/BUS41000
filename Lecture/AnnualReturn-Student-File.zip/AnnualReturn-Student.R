# Please run this line before going forward [tell R the location of SP500.csv file]
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## Q1: Calculate Mean and Variance of SP500

df = read.csv(file = "SP500.csv", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
SP500 = as.numeric(sub("%", "", df$S.P.500..includes.dividends.))
mean(SP500)
sd(SP500)


## Q2: Only invest $1 in the first year
returns = matrix(rnorm(n = 5000*20, mean = 11, sd = 19), nrow = 5000, ncol=20)/100
wealth = apply(1+returns, 1, prod)

### Summary Statistics
mean(wealth)
median(wealth)


## Q3: Invest $1 every year
returns = matrix(rnorm(n = 5000*20, mean = 11, sd = 19), nrow = 5000, ncol=20)/100

wealth = apply(1+returns, 1, prod)
for (i in 1:19){
  wealth = wealth + apply(matrix(1+returns[,(i+1):20],nrow = 5000, ncol = 20-i), 1, prod)
}

### Summary Statistics
mean(wealth)
median(wealth)


## Below is for visualizing the wealth PGF

###  Plot the PGF
d = density(wealth)
plot(d, xlab="total wealth in $", ylab = "density",
     main = "Total wealth in 20 years")
abline(v = mean(wealth), col = 'red', lty=2)
abline(v = median(wealth), col = 'blue', lty=2)
legend("topright",
       legend = c(paste("mean ", round(mean(wealth),2)),
                  paste("median ", round(median(wealth),2))),
       col = c('red', 'blue'), lty = c(2,2))

