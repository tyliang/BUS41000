### BUSN 41000 Business Statistics
### Fall, 2020
### Homework 3
### Shuo-Chieh Huang

# This script is to help you load the data for Homework 3 into R.
# I have already extract the data out for you. 
# After you run ALL the following codes here, you can proceed with your own code.

# Problem 1.
# For this problem we need the data for the monthly return rate of VTI and VGLT.
# I have stored in the "Q1.csv" file in the same folder these data.
# Now let's load them into your R studio console. 
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
data_Q1 = read.csv( "Q1", header=T, row.names=1 )
VTI  = data_Q1[,"VTI"]
VGLT = data_Q1[,"VGLT"]

# There you go. We now have the data VTI and VGLT.
# While we are at it, let's explore a bit by looking at the data.
# Some sanity check
head( data_Q1 )

# Plot (The red one is VTI, the green VGLT)
dates <- as.Date( row.names(data_Q1) )
matplot( data_Q1, type="l", lty=c(1,1), col=c(2,3), xaxt="n", xlab="" )
axis( 1, 1:nrow(data_Q1), format(dates, "%m/%y"), cex.axis=0.7, las=2 )

# Mean and standard deviation
mean( VTI )
mean( VGLT )
sd( VTI )
sd( VGLT )
as.numeric( cov( VTI, VGLT ) )

# In this problem, you need to build the efficient frontier by combining these two ETFs.
# To do so, we can tell R to generate a sequence of combinations, instead of hand-coding it.
weights = seq( from=0, to=1, length.out=1000 )
mean_port = weights * mean( VTI ) + ( 1 - weights ) * mean( VGLT )
sd_port = sqrt( weights^2 * sd(VTI)^2 + (1 - weights)^2 * sd(VGLT)^2 + 
                2 * weights * (1 - weights) * cov(VTI,VGLT) )
plot(sd_port, mean_port)

# Now try to answer the rest of the qestion!

# Problem 2.
# For this problem let's invest in SPY, the biggest ETF of S&P 500, and
# in TLT, an ETF of long term U.S. treasury.
# Again I have prepared the data in the same file.
data_Q2 = read.csv( "Q2", header=T, row.names=1 )
SPY     = data_Q2[,"SPY"]
TLT     = data_Q2[,"TLT"]

# Again some sanity check.
head( data_Q2 )

# Plot (The red one is SPY, the green TLT)
dates <- as.Date( row.names(data_Q2) )
matplot( data_Q2, type="l", lty=c(1,1), col=c(2,3), xaxt="n", xlab="" )
axis( 1, 1:nrow(data_Q1), format(dates, "%m/%y"), cex.axis=0.7, las=2 )

# Mean and standard deviation
mean( SPY )
mean( TLT )
sd( SPY )
sd( TLT )
as.numeric( cov( SPY, TLT ) )

# To assess a plausible range for Prof. Liang's investment,
# one thing we can do is to simulate it.
# We now have the mean and sd of SPY index. Why don't we simulate
# 20 years' returns as a sequence of normal distribution with the 
# same mean and sd? 
# The R code that does this trick is "rnorm" (see below.)

M = 100        # Number of simulations. (You can increase the number for higher accuracy, at the cost of your computer's labor.)
N = 240        # Investment horizon. (20 years = 240 months)
initial_asset = 100000 # self-explanatory

# You may need to parse the following paragraph a bit.
# You might need to modify them in later questions.
# These lines are telling R to do the tedious work of simulating M times
# the asset's realization over the N-month horizon.
# The first key is that in the "rnorm" function, we need to supply R with the desired
# mean and standard deviation.
# The second key is that asset at time (t+1) is just (1+return) times the asset
# at time t, hence the recursive relationship. Of course, return is simulated.
asset     = matrix( 0, N+1, M )
asset[1,] = initial_asset
for( i in 1:M){
  for(t in 1:N){
    asset[t+1,i] = asset[t,i] * (1 + rnorm(1, mean=mean(SPY), sd=sd(SPY) ) )
  }
}
endvalue = tail( asset, 1 )

# Now we have 100 simulated outcomes. What is their distribution?
hist( endvalue, main="Histogram of simulated outcomes" )

# Finally we have the mean and sd
mean( endvalue )
sd( endvalue )

# Can you finish the rest of the questions?




